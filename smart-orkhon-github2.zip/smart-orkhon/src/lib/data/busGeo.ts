// Bus routes drawn on the map. Only routes whose ordered stop list is published can be drawn; Ч1–Ч7 have
// names and endpoints on erdenet.mn but no stop lists, so they are listed without a line rather than guessed.
//
// Ч8 line: the stops on the official route map (2024-07-03 news item, map by Хот тохижуулах газар) were matched
// to named places in OpenStreetMap, then joined along OSM roads with the OSRM router (2026-11-21) and simplified.
// The result follows the schematic but is approximate: the bus may use different streets between stops.

import { OFFICIAL_LINES, SEEDED_ROUTES } from "./bus";

export type LatLng = [number, number];
/** `no` is the stop's position in the official stop list (1-based). */
export interface MapStop { name: string; lat: number; lng: number; no: number }
export interface BusMapLine {
  code: string;
  name: string;
  color: string;
  /** null when the stop list is not published, so no line can be drawn honestly. */
  path: LatLng[] | null;
  /** Stops that could be matched to a named place in OSM, in route order. */
  stops: MapStop[];
  /** How many stops the official list has in total. */
  stopCount?: number;
  lengthKm?: number;
  loop?: boolean;
  source: string;
}

/** Window event that switches the map section to its bus layer (sent by the bus section's map button). */
export const MAP_BUS_EVENT = "smart-orkhon:map-bus";

export const BUS_GEO_SOURCES = {
  schematic: "https://erdenet.mn/medee/show/240700009",
  osm: "https://www.openstreetmap.org/copyright",
  osrm: "https://project-osrm.org",
};

const CH8_PATH: LatLng[] = [[49.02422,104.04708],[49.02419,104.04681],[49.02402,104.04664],[49.02385,104.04668],[49.02372,104.04692],[49.02377,104.04728],[49.024,104.04742],[49.02539,104.04652],[49.02555,104.04689],[49.02572,104.04672],[49.02565,104.04634],[49.02747,104.04502],[49.02596,104.03985],[49.02509,104.03641],[49.02607,104.03578],[49.02581,104.03464],[49.02609,104.03461],[49.02631,104.03519],[49.02647,104.03506],[49.02629,104.03415],[49.02606,104.03415],[49.02564,104.03363],[49.02443,104.03435],[49.02336,104.03078],[49.02081,104.03165],[49.01958,104.03244],[49.01834,104.029],[49.02091,104.02707],[49.01953,104.02133],[49.01857,104.01651],[49.01804,104.01429],[49.01571,104.01554],[49.01491,104.01613],[49.01436,104.01672],[49.013,104.0186],[49.0128,104.01861],[49.01261,104.01851],[49.00961,104.01353],[49.00837,104.01178],[49.00681,104.0102],[49.00311,104.00677],[49.0018,104.00586],[49.00063,104.00534],[48.99926,104.00492],[48.99712,104.00481],[48.99527,104.00519],[48.99186,104.0068],[48.99202,104.00829],[48.99188,104.00859],[48.9919,104.00888],[48.99318,104.01291],[48.99303,104.01339],[48.99331,104.01431],[48.99419,104.01632],[48.99255,104.01742],[48.99217,104.01788],[48.99195,104.0184],[48.99164,104.01998],[48.99095,104.02183],[48.99057,104.02163],[48.98989,104.02203],[48.99316,104.03221],[48.99482,104.0314],[48.99509,104.03274],[48.99683,104.03246],[48.99709,104.03162],[48.99801,104.03008],[48.99837,104.02893],[48.99979,104.02676],[49.00074,104.02564],[49.0018,104.0247],[49.00283,104.02414],[49.00478,104.02341],[49.00631,104.02334],[49.00719,104.02286],[49.00763,104.0224],[49.00841,104.02052],[49.00857,104.02037],[49.00902,104.0203],[49.00965,104.0197],[49.01167,104.01694],[49.01697,104.02587],[49.01774,104.02748],[49.01958,104.03244],[49.02002,104.03216],[49.02041,104.0336],[49.02027,104.03385],[49.02028,104.03404],[49.02016,104.03412],[49.02388,104.04621],[49.02388,104.04666],[49.02372,104.04692],[49.02374,104.04719],[49.024,104.04742],[49.02422,104.04708]];

const CH8_ORDER = SEEDED_ROUTES.find((r) => r.number === "Ч8")?.stops ?? [];
const CH8_STOPS: MapStop[] = ([

  { name: "Кувейтын тойрог", lat: 49.02401, lng: 104.04704 },
  { name: "Даниста", lat: 49.02551, lng: 104.04718 },
  { name: "Мэнд-Амар", lat: 49.02708, lng: 104.04243 },
  { name: "Их хаадын цуваа", lat: 49.0263, lng: 104.035 },
  { name: "Сансар ХТ", lat: 49.02049, lng: 104.0329 },
  { name: "Цагаан худаг", lat: 49.01946, lng: 104.02119 },
  { name: "Петровис ШТС", lat: 48.99049, lng: 104.0217 },
  { name: "20-р сургууль", lat: 48.99384, lng: 104.03023 },
  { name: "Пинк", lat: 48.99644, lng: 104.0321 },
  { name: "14-р сургууль", lat: 49.02432, lng: 104.04353 },
] as Omit<MapStop, "no">[]).map((s) => ({ ...s, no: CH8_ORDER.indexOf(s.name) + 1 }));

// One colour per line, chosen to stay apart from the traffic greens/ambers/reds.
const COLORS: Record<string, string> = {
  "Ч1, Ч2": "#f472b6", Ч3: "#38bdf8", Ч4: "#fb923c", Ч5: "#facc15", Ч6: "#2dd4bf", Ч7: "#818cf8", Ч8: "#c084fc",
};

export const BUS_MAP_LINES: BusMapLine[] = OFFICIAL_LINES.map((l) =>
  l.code === "Ч8"
    ? { code: l.code, name: l.name, color: COLORS[l.code], path: CH8_PATH, stops: CH8_STOPS, stopCount: 21, lengthKm: 15, loop: true, source: l.source }
    : { code: l.code, name: l.name, color: COLORS[l.code] ?? "#94a3b8", path: null, stops: [], source: l.source });

const R = Math.PI / 180;
/** Points every `stepM` metres along a path with the travel bearing there (degrees clockwise from north), for arrows. */
export function arrowsAlong(path: LatLng[], stepM = 650): { at: LatLng; deg: number }[] {
  const out: { at: LatLng; deg: number }[] = [];
  let next = stepM / 2;
  let walked = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const [aLat, aLng] = path[i], [bLat, bLng] = path[i + 1];
    const dy = (bLat - aLat) * 111320, dx = (bLng - aLng) * 111320 * Math.cos(aLat * R);
    const seg = Math.hypot(dx, dy);
    while (seg > 0 && walked + seg >= next) {
      const t = (next - walked) / seg;
      out.push({ at: [aLat + (bLat - aLat) * t, aLng + (bLng - aLng) * t], deg: (Math.atan2(dx, dy) / R + 360) % 360 });
      next += stepM;
    }
    walked += seg;
  }
  return out;
}
