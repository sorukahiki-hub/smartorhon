import type { AnnouncementCategory, IssueCategory, IssueStatus, Verification } from "./types";

export const ANN_CAT: Record<AnnouncementCategory, { label: string; color: string }> = {
  water: { label: "Ус", color: "#38bdf8" },
  electricity: { label: "Цахилгаан", color: "#facc15" },
  road: { label: "Зам засвар", color: "#fb923c" },
  traffic: { label: "Замын түгжрэл", color: "#f43f5e" },
  transport: { label: "Нийтийн тээвэр", color: "#a78bfa" },
  waste: { label: "Хог хаягдал", color: "#4ade80" },
  environment: { label: "Байгаль орчин", color: "#00d9a5" },
  service: { label: "Төрийн үйлчилгээ", color: "#00e5ff" },
  emergency: { label: "Онцгой байдал", color: "#ff5a6e" },
};

export const ISSUE_CAT: Record<IssueCategory, string> = {
  road: "Зам, дэд бүтэц",
  air: "Агаарын бохирдол",
  waste: "Хог хаягдал",
  transport: "Нийтийн тээвэр",
  lighting: "Гэрэлтүүлэг",
  water: "Ус, байгаль орчин",
  education: "Боловсрол",
  health: "Эрүүл мэнд",
};

export const STATUS: Record<IssueStatus, { label: string; color: string; cls: string }> = {
  new: { label: "Шинээр бүртгэгдсэн", color: "#ff5a6e", cls: "text-alert border-alert/40 bg-alert/10" },
  progress: { label: "Шийдвэрлэх шатанд", color: "#ffc24b", cls: "text-warn border-warn/40 bg-warn/10" },
  resolved: { label: "Шийдвэрлэгдсэн", color: "#00d9a5", cls: "text-emerald border-emerald/40 bg-emerald/10" },
};

export const VERIFY: Record<Verification, { label: string; cls: string }> = {
  "verified-note": { label: "Гараар шалгасан", cls: "text-emerald border-emerald/40 bg-emerald/10" },
  demo: { label: "Жишээ мэдээлэл", cls: "text-warn border-warn/40 bg-warn/10" },
  unverified: { label: "Баталгаажаагүй", cls: "text-alert border-alert/40 bg-alert/10" },
  live: { label: "Шууд мэдээлэл (камер)", cls: "text-cyan border-cyan/40 bg-cyan/10" },
};

export function fmtDate(iso?: string, withTime = false): string {
  if (!iso) return "Тодорхойгүй";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "Тодорхойгүй";
  const p = (n: number) => String(n).padStart(2, "0");
  const s = `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`;
  return withTime ? `${s} ${p(d.getHours())}:${p(d.getMinutes())}` : s;
}
