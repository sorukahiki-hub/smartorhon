import {
  BarChart3, Bell, Building2, Bus, CheckCircle2, FileText, Home, Info, Landmark, Map as MapIcon, Megaphone, Siren, Smartphone, Trash2,
  type LucideIcon,
} from "lucide-react";

// Phone navigation, shared by the real bottom bar and the phone screens drawn in the «Апп татах» section,
// so the app design and the site always match.
export type NavItem = { href: string; label: string; icon: LucideIcon };

export const TABS: (NavItem & { primary?: boolean })[] = [
  { href: "#home", label: "Нүүр", icon: Home },
  { href: "#notices", label: "Мэдэгдэл", icon: Bell },
  { href: "#report", label: "Мэдээлэх", icon: Megaphone, primary: true },
  { href: "#bus", label: "Автобус", icon: Bus },
];

export const MENU: NavItem[] = [
  { href: "#alerts", label: "Шуурхай мэдээ", icon: Siren },
  { href: "#notices", label: "Мэдэгдэл", icon: Bell },
  { href: "#report", label: "Асуудал мэдээлэх", icon: Megaphone },
  { href: "#map", label: "Газрын зураг", icon: MapIcon },
  { href: "#bus", label: "Автобус", icon: Bus },
  { href: "#services", label: "Үйлчилгээ", icon: Building2 },
  { href: "#visit", label: "Үзэх газар", icon: Landmark },
  { href: "#garbage", label: "Хог ачилт", icon: Trash2 },
  { href: "#solved", label: "Үр дүн, санаа", icon: CheckCircle2 },
  { href: "#stats", label: "Статистик", icon: BarChart3 },
  { href: "#summarizer", label: "Зар ойлгох", icon: FileText },
  { href: "#app", label: "Апп татах", icon: Smartphone },
  { href: "#about", label: "Бидний тухай", icon: Info },
];
