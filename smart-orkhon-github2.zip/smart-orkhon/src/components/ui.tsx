// Small shadcn/ui-style primitives (cva + tailwind-merge) shared across sections.
import { cva, type VariantProps } from "class-variance-authority";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { ButtonHTMLAttributes, HTMLAttributes, ReactNode } from "react";

export const cn = (...v: ClassValue[]) => twMerge(clsx(v));

export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all disabled:pointer-events-none disabled:opacity-50 whitespace-nowrap",
  {
    variants: {
      variant: {
        primary: "bg-cyan text-navy shadow-[0_0_24px_-4px_rgba(0,229,255,.6)] hover:bg-[#5ff0ff] hover:shadow-[0_0_32px_-2px_rgba(0,229,255,.75)]",
        emerald: "bg-emerald text-navy hover:bg-[#3ff0c2] shadow-[0_0_24px_-6px_rgba(0,217,165,.6)]",
        ghost: "border border-line bg-white/5 text-snow hover:border-cyan/50 hover:bg-cyan/10",
        subtle: "text-muted hover:text-snow hover:bg-white/5",
      },
      size: { sm: "h-8 px-3 text-xs", md: "h-10 px-4 text-sm", lg: "h-12 px-6 text-base" },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export function Button({ className, variant, size, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>) {
  return <button className={cn(buttonVariants({ variant, size }), className)} {...p} />;
}

export function Card({ className, ...p }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("glass rounded-2xl", className)} {...p} />;
}

export function Badge({ className, children, color }: { className?: string; children: ReactNode; color?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[12.5px] font-semibold leading-5", className)}
      style={color ? { color, borderColor: color + "66", background: color + "1a" } : undefined}>
      {children}
    </span>
  );
}

export function SectionHead({ id, eyebrow, title, lead, right }: { id?: string; eyebrow: string; title: string; lead?: string; right?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="max-w-2xl">
        <p className="mb-2 text-xs font-bold uppercase tracking-[0.1em] text-cyan">{eyebrow}</p>
        <h2 id={id} className="font-display text-2xl font-bold leading-tight text-snow md:text-[2rem]">{title}</h2>
        {lead && <p className="mt-3 text-base leading-relaxed text-muted">{lead}</p>}
      </div>
      {right}
    </div>
  );
}

export function DemoTag({ children = "Жишээ мэдээлэл" }: { children?: ReactNode }) {
  return <Badge className="border-warn/40 bg-warn/10 text-warn">{children}</Badge>;
}

export function Empty({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-line px-6 py-10 text-center">
      <p className="font-semibold text-snow">{title}</p>
      {text && <p className="max-w-sm text-sm text-muted">{text}</p>}
      {action}
    </div>
  );
}

export function Field({ label, htmlFor, children, hint }: { label: string; htmlFor: string; children: ReactNode; hint?: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={htmlFor} className="text-sm font-semibold text-snow">{label}</label>
      {children}
      {hint && <p className="text-xs text-muted">{hint}</p>}
    </div>
  );
}

export const inputCls = "w-full rounded-xl border border-line bg-navy/70 px-3.5 py-2.5 text-sm text-snow placeholder:text-muted/70 focus:border-cyan/60 focus:outline-none";
