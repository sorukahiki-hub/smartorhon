"use client";

import dynamic from "next/dynamic";
import { AlertCircle, Bot, Bus as BusIcon, CalendarDays, Car, MapPin, ShieldCheck, X, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { SEEDED_ROUTES } from "@/lib/data/bus";
import { BUS_GEO_SOURCES, BUS_MAP_LINES, MAP_BUS_EVENT } from "@/lib/data/busGeo";
import { ALERT_KIND, ALERT_LEVEL, OUTAGE_KINDS, isOpen, type AlertKind } from "@/lib/civic";
import { DEMO_ISSUES, VERIFIED_SPOTS } from "@/lib/data/places";
import { ISSUE_CAT, STATUS, fmtDate } from "@/lib/labels";
import type { IssueStatus } from "@/lib/types";
import { trafficColor, useStore } from "@/lib/store";

const hm = (iso: string) => new Date(iso).toLocaleTimeString("mn-MN", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Ulaanbaatar" });
import { Badge, Button, Card, DemoTag, SectionHead, cn } from "./ui";

const LeafletMap = dynamic(() => import("./LeafletMap"), {
  ssr: false,
  loading: () => <div className="grid h-[480px] place-items-center rounded-[1.25rem] bg-navy-2 text-sm text-muted md:h-[560px]">Газрын зураг ачаалж байна…</div>,
});

type Layer = "issues" | "traffic" | "outages" | "bus";
const LAYERS: { id: Layer; label: string; icon: typeof Car }[] = [
  { id: "issues", label: "Иргэдийн асуудал", icon: AlertCircle },
  { id: "traffic", label: "Замын ачаалал", icon: Car },
  { id: "outages", label: "Ус, цахилгаан тасралт", icon: Zap },
  { id: "bus", label: "Автобусны чиглэл", icon: BusIcon },
];
const DRAWN = BUS_MAP_LINES.filter((l) => l.path);
const UNDRAWN = BUS_MAP_LINES.filter((l) => !l.path);

export function MapSection() {
  const { askAI, traffic, prefs, alerts } = useStore();
  // One layer at a time, so outages are never mixed up with road load or reported problems.
  const [layer, setLayer] = useState<Layer>("issues");
  const [busOn, setBusOn] = useState<string[]>(DRAWN.map((l) => l.code));
  const [stopKey, setStopKey] = useState<string | null>(null);
  const [status, setStatus] = useState<"all" | IssueStatus>("all");
  const [kinds, setKinds] = useState<AlertKind[]>(OUTAGE_KINDS);
  const [selected, setSelected] = useState<string | null>(null);
  const [spot, setSpot] = useState<string | null>(null);
  const [camName, setCamName] = useState<string | null>(null);
  const [outageId, setOutageId] = useState<number | null>(null);
  const [showVerified, setShowVerified] = useState(false);
  const showTraffic = layer === "traffic";
  const issues = layer === "issues" ? DEMO_ISSUES.filter((i) => status === "all" || i.status === status) : [];
  const sel = DEMO_ISSUES.find((i) => i.id === selected);
  const sp = VERIFIED_SPOTS.find((s) => s.id === spot);
  const cameras = showTraffic && traffic?.ok ? traffic.spots : [];
  const cam = cameras.find((c) => c.name === camName);
  const openOutages = (alerts ?? []).filter((a) => OUTAGE_KINDS.includes(a.kind) && isOpen(a));
  const outages = layer === "outages" ? openOutages.filter((a) => kinds.includes(a.kind) && a.lat != null && a.lng != null) : [];
  const outage = outages.find((a) => a.id === outageId);
  const busLines = layer === "bus" ? DRAWN.filter((l) => busOn.includes(l.code)) : [];
  const stopLine = stopKey ? DRAWN.find((l) => stopKey.startsWith(l.code + ":")) : undefined;
  const stop = stopLine?.stops.find((s) => `${stopLine.code}:${s.no}` === stopKey);
  const stopRoute = stopLine ? SEEDED_ROUTES.find((r) => r.number === stopLine.code) : undefined;
  const clear = () => { setSelected(null); setSpot(null); setCamName(null); setOutageId(null); setStopKey(null); };
  useEffect(() => {
    const open = () => { setSelected(null); setSpot(null); setCamName(null); setOutageId(null); setStopKey(null); setLayer("bus"); };
    window.addEventListener(MAP_BUS_EVENT, open);
    return () => window.removeEventListener(MAP_BUS_EVENT, open);
  }, []);

  return (
    <section id="map" className="mx-auto max-w-7xl px-4 py-14 md:py-20 md:px-6" aria-labelledby="map-title">
      <SectionHead id="map-title" eyebrow="Интерактив 2D газрын зураг" title="Эрдэнэт хотын газрын зураг"
        lead="Доорх товчоор давхаргаа сонгоно: иргэдийн мэдээлсэн асуудал, камерын шууд тооллогоор замын ачаалал (5 минут тутам), ус, цахилгаан, дулааны тасралт, эсвэл автобусны чиглэл (өнгө өнгөөр, сумаар явах чиглэлтэй). Нэг удаад нэг давхарга харагдана."
        right={layer === "issues" ? <DemoTag>Асуудлын цэгүүд жишээ байршилтай</DemoTag> : layer === "bus" ? <DemoTag>Чиглэлийн шугам ойролцоо</DemoTag> : undefined} />
      <div role="tablist" aria-label="Газрын зургийн давхарга" className="mb-3 inline-flex w-full flex-wrap gap-1 rounded-2xl border border-line bg-white/[.03] p-1 sm:w-auto">
        {LAYERS.map(({ id, label, icon: Icon }) => (
          <button key={id} type="button" role="tab" aria-selected={layer === id} onClick={() => { clear(); setLayer(id); }}
            className={cn("flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-3.5 py-2 text-sm font-semibold transition sm:flex-none",
              layer === id ? "bg-cyan text-navy" : "text-muted hover:bg-white/5 hover:text-snow")}>
            <Icon className="h-4 w-4" />{label}
            {id === "outages" && openOutages.length > 0 && <span className={cn("rounded-full px-1.5 text-xs font-bold", layer === id ? "bg-navy/20" : "bg-alert text-white")}>{openOutages.length}</span>}
          </button>
        ))}
      </div>
      <div className="mb-4 flex min-h-9 flex-wrap items-center gap-2">
        {layer === "issues" && (
          <>
            {(["all", "new", "progress", "resolved"] as const).map((s) => (
              <button key={s} type="button" aria-pressed={status === s} onClick={() => setStatus(s)}
                className={cn("flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition", status === s ? "border-cyan bg-cyan/15 text-snow" : "border-line text-muted hover:text-snow")}>
                {s !== "all" && <span className="h-2.5 w-2.5 rounded-full" style={{ background: STATUS[s].color, boxShadow: `0 0 8px ${STATUS[s].color}` }} />}
                {s === "all" ? "Бүгд" : STATUS[s].label}
              </button>
            ))}
          </>
        )}
        {layer === "traffic" && (
          <label className="flex cursor-pointer items-center gap-2 text-sm text-muted"><input type="checkbox" className="h-4 w-4 accent-[#00e5ff]" checked={showVerified} onChange={(e) => setShowVerified(e.target.checked)} />Шалгасан замын цэгүүд</label>
        )}
        {layer === "outages" && OUTAGE_KINDS.map((k) => (
          <button key={k} type="button" aria-pressed={kinds.includes(k)} onClick={() => { setOutageId(null); setKinds((x) => (x.includes(k) ? x.filter((y) => y !== k) : [...x, k])); }}
            className={cn("flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition", kinds.includes(k) ? "text-snow" : "border-line text-muted line-through opacity-70")}
            style={kinds.includes(k) ? { borderColor: ALERT_KIND[k].color, background: ALERT_KIND[k].color + "22" } : undefined}>
            <span aria-hidden>{ALERT_KIND[k].icon}</span>{ALERT_KIND[k].label}
            <span className="text-xs text-muted">{openOutages.filter((a) => a.kind === k).length}</span>
          </button>
        ))}
        {layer === "bus" && DRAWN.map((l) => {
          const on = busOn.includes(l.code);
          return (
            <button key={l.code} type="button" aria-pressed={on} onClick={() => { setStopKey(null); setBusOn((x) => (on ? x.filter((c) => c !== l.code) : [...x, l.code])); }}
              className={cn("flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition", on ? "text-snow" : "border-line text-muted line-through opacity-70")}
              style={on ? { borderColor: l.color, background: l.color + "22" } : undefined}>
              <span className="h-1.5 w-5 rounded-full" style={{ background: l.color }} />{l.code}
            </button>
          );
        })}
        {layer === "bus" && UNDRAWN.length > 0 && <span className="text-xs text-muted">{UNDRAWN.map((l) => l.code).join(", ")}: зогсоолын жагсаалт нийтлэгдээгүй тул зураагүй</span>}
      </div>
      {showTraffic && (
        <p className="mb-3 flex flex-wrap items-center gap-x-2 text-xs text-muted" aria-live="polite">
          <span className="font-semibold text-cyan">Шууд мэдээлэл:</span>
          {!prefs.topics.traffic ? "Мэдэгдлийн тохиргоонд «Замын түгжрэл» унтраалттай тул камерын мэдээлэл татахгүй байна."
            : !traffic ? "Камерын мэдээлэл ачаалж байна…"
            : !traffic.ok ? "Камерын төвөөс мэдээлэл татаж чадсангүй. 5 минутын дараа дахин оролдоно."
            : `${traffic.total} камер (${traffic.cameras} нь машин тоолдог), ${traffic.busy.length} нь ачаалалтай · ${hm(traffic.fetchedAt)}-ийн байдлаар · 5 минут тутам автоматаар шинэчилнэ. Цэг доторх тоо = машины тоо. Зам нь ойролцоох (${250} м) камерын өнгөөр, камергүй хэсэг саарал.`}
        </p>
      )}
      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="glass relative min-w-0 overflow-hidden rounded-3xl p-1.5">
          <LeafletMap issues={issues} selected={selected} onSelect={(id) => { clear(); setSelected(id); }} showVerified={showTraffic && showVerified} onSelectSpot={(id) => { clear(); setSpot(id); }}
            cameras={cameras} selectedCam={camName} onSelectCam={(n) => { clear(); setCamName(n); }}
            outages={outages} selectedOutage={outageId} onSelectOutage={(id) => { clear(); setOutageId(id); }}
            busLines={busLines} selectedStop={stopKey} onSelectStop={(k) => { clear(); setStopKey(k); }} />
        </div>
        <Card className="flex min-w-0 flex-col p-5">
          {layer === "bus" ? (
            stopLine && stop ? (
              <div>
                <div className="flex items-start justify-between gap-2">
                  <Badge color={stopLine.color}>{stopLine.code} · {stop.no}-р зогсоол</Badge>
                  <button type="button" onClick={() => setStopKey(null)} className="grid h-7 w-7 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-4 w-4" /></button>
                </div>
                <h3 className="mt-3 text-lg font-semibold">{stop.name}</h3>
                <p className="mt-1 text-xs text-muted">{stopLine.name}</p>
                {stopRoute && (
                  <dl className="mt-4 space-y-2 text-sm">
                    {stop.no > 1 && <div className="text-muted">Өмнөх: <span className="text-snow">{stopRoute.stops[stop.no - 2]}</span></div>}
                    {stop.no < stopRoute.stops.length && <div className="text-muted">Дараагийн: <span className="text-snow">{stopRoute.stops[stop.no]}</span></div>}
                    {stopRoute.departures?.length ? (
                      <div>
                        <p className="text-muted">Хөдлөх цаг (албан чиглэлийн зургаас):</p>
                        <p className="mt-1 flex flex-wrap gap-1">{stopRoute.departures.map((t) => <span key={t} className="rounded-md border border-line px-1.5 py-0.5 text-xs">{t}</span>)}</p>
                      </div>
                    ) : null}
                  </dl>
                )}
                <p className="mt-3 text-xs text-muted">Зогсоолын байршлыг OpenStreetMap дээрх ижил нэртэй газраас тогтоосон тул хэдэн арван метр зөрж болно.</p>
                <a href="#bus" className="mt-4 block text-sm font-semibold text-cyan">Чиглэлийн бүх зогсоол, цаг →</a>
                <Button className="mt-3 w-full" variant="ghost" size="sm" onClick={() => askAI(`${stop.name} буудлаар ямар автобус явдаг вэ?`)}><Bot className="h-4 w-4" />AI-аас асуух</Button>
              </div>
            ) : (
              <div className="flex h-full flex-col">
                <h3 className="font-semibold">Автобусны чиглэлүүд</h3>
                <ul className="mt-3 space-y-2.5 text-sm">
                  {DRAWN.map((l) => (
                    <li key={l.code} className="rounded-xl border border-line p-3">
                      <div className="flex items-center gap-2.5"><span className="h-1.5 w-6 shrink-0 rounded-full" style={{ background: l.color }} /><span className="font-semibold">{l.code}</span><span className="truncate text-muted">{l.name}</span></div>
                      <p className="mt-2 text-xs text-muted">{l.loop ? "Тойрог чиглэл, сум нь явах чиглэлийг заана. " : ""}{l.stopCount ? `${l.stopCount} зогсоолоос ${l.stops.length}-ийг нь газрын зураг дээр дугаартай цэгээр тэмдэглэв. ` : ""}{l.lengthKm ? `Урт нь ойролцоогоор ${l.lengthKm} км.` : ""}</p>
                      <ul className="mt-2 flex flex-wrap gap-1">
                        {l.stops.map((s) => <li key={s.no}><button type="button" onClick={() => { clear(); setStopKey(`${l.code}:${s.no}`); }} className="rounded-md border border-line px-1.5 py-0.5 text-xs hover:border-cyan hover:text-snow">{s.no}. {s.name}</button></li>)}
                      </ul>
                    </li>
                  ))}
                  {UNDRAWN.map((l) => (
                    <li key={l.code} className="flex items-center gap-2.5 px-1 text-muted">
                      <span className="h-1.5 w-6 shrink-0 rounded-full border border-dashed" style={{ borderColor: l.color }} /><span className="font-semibold text-snow/80">{l.code}</span><span className="truncate">{l.name}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-4 text-xs leading-relaxed text-muted">
                  Шугамыг <a className="text-cyan underline" href={BUS_GEO_SOURCES.schematic} target="_blank" rel="noopener noreferrer">албан ёсны чиглэлийн зураг</a>-ийн зогсоолуудаар,{" "}
                  <a className="text-cyan underline" href={BUS_GEO_SOURCES.osm} target="_blank" rel="noopener noreferrer">OpenStreetMap</a>-ийн замаар{" "}
                  (<a className="text-cyan underline" href={BUS_GEO_SOURCES.osrm} target="_blank" rel="noopener noreferrer">OSRM</a>) сэргээсэн тул ойролцоо: автобус зогсоол хооронд өөр гудамжаар явж болно.
                  {UNDRAWN.length > 0 && ` ${UNDRAWN.map((l) => l.code).join(", ")}-ийн зогсоолын жагсаалт албан сайтад нийтлэгдээгүй тул шугамыг таамаглаж зураагүй.`}
                </p>
                <a href="#bus" className="mt-auto pt-4 text-sm font-semibold text-cyan">Хөдлөх цаг, үнэ, бүх чиглэл →</a>
              </div>
            )
          ) : layer === "outages" ? (
            outage ? (
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-wrap gap-1.5"><Badge color={ALERT_LEVEL[outage.level].color}>{ALERT_LEVEL[outage.level].label}</Badge><Badge color={ALERT_KIND[outage.kind].color}>{ALERT_KIND[outage.kind].icon} {ALERT_KIND[outage.kind].label}</Badge></div>
                  <button type="button" onClick={() => setOutageId(null)} className="grid h-7 w-7 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-4 w-4" /></button>
                </div>
                <h3 className="mt-3 text-lg font-semibold">{outage.title}</h3>
                {outage.area && <p className="mt-1 flex items-center gap-1.5 text-sm text-muted"><MapPin className="h-4 w-4 text-cyan" />{outage.area}</p>}
                {outage.body && <p className="mt-3 whitespace-pre-line text-sm leading-relaxed">{outage.body}</p>}
                <dl className="mt-3 space-y-1 text-sm text-muted">
                  {outage.startsAt && <div>Эхлэх: <span className="text-snow">{fmtDate(outage.startsAt, true)}</span></div>}
                  {outage.endsAt && <div>Дуусах (таамаг): <span className="text-snow">{fmtDate(outage.endsAt, true)}</span></div>}
                  {outage.source && <div>Эх сурвалж: {outage.source}</div>}
                </dl>
                <a href="#alerts" className="mt-4 block text-sm font-semibold text-cyan">Бүх шуурхай мэдээлэл →</a>
                <Button className="mt-3 w-full" variant="ghost" size="sm" onClick={() => askAI(`${outage.area || outage.title} — ${ALERT_KIND[outage.kind].label.toLowerCase()} хэзээ сэргэх вэ?`)}><Bot className="h-4 w-4" />AI-аас асуух</Button>
              </div>
            ) : (
              <div className="flex h-full flex-col">
                <h3 className="font-semibold">Идэвхтэй тасралт</h3>
                {alerts === null ? <div className="mt-3 h-24 animate-pulse rounded-xl bg-white/5" /> : outages.length ? (
                  <ul className="mt-3 space-y-1 text-sm">
                    {outages.map((a) => (
                      <li key={a.id}><button type="button" onClick={() => setOutageId(a.id)} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left hover:bg-white/5">
                        <span aria-hidden>{ALERT_KIND[a.kind].icon}</span><span className="truncate">{a.title}</span><span className="ml-auto shrink-0 text-xs text-muted">{a.area}</span>
                      </button></li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-3 rounded-xl border border-line p-3 text-sm text-muted">{openOutages.length ? "Сонгосон төрлийн, байршилтай тасралт алга." : "Одоогоор ус, цахилгаан, дулааны идэвхтэй тасралт бүртгэгдээгүй байна."}</p>
                )}
                {openOutages.some((a) => a.lat == null) && <p className="mt-3 text-sm text-muted">Байршилгүй {openOutages.filter((a) => a.lat == null).length} мэдээллийг <a href="#alerts" className="text-cyan underline">шуурхай мэдээлэл</a> хэсгээс харна уу.</p>}
                <ul className="mt-5 space-y-2 text-sm">
                  {OUTAGE_KINDS.map((k) => <li key={k} className="flex items-center gap-2.5"><span className="grid h-6 w-6 place-items-center rounded-full text-xs" style={{ background: ALERT_KIND[k].color + "33", border: `2px solid ${ALERT_KIND[k].color}` }}>{ALERT_KIND[k].icon}</span>{ALERT_KIND[k].label}</li>)}
                </ul>
                <p className="mt-auto pt-5 text-sm text-muted">Тасралтын мэдээллийг албан ёсны эх сурвалжаас админ оруулна. Цэг дээр дарж дэлгэрэнгүйг харна.</p>
              </div>
            )
          ) : cam ? (
            <div>
              <div className="flex items-start justify-between gap-2">
                <Badge color={trafficColor(cam.rank)}>{cam.levelLabel}</Badge>
                <button type="button" onClick={() => setCamName(null)} className="grid h-7 w-7 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-4 w-4" /></button>
              </div>
              <h3 className="mt-3 text-lg font-semibold">{cam.name}</h3>
              <p className="mt-1 text-xs text-muted">Орхон аймгийн ТКХДТ · камерын автомат тооллого</p>
              {cam.vehicles != null && cam.detectedAt ? (
                <>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <div className="rounded-xl border border-line p-3"><p className="text-[12.5px] text-muted">Машин</p><p className="font-display text-2xl font-semibold" style={{ color: trafficColor(cam.rank) }}>{cam.vehicles}</p></div>
                    <div className="rounded-xl border border-line p-3"><p className="text-[12.5px] text-muted">Бүртгэсэн</p><p className="font-display text-2xl font-semibold">{hm(cam.detectedAt)}</p></div>
                  </div>
                  <Badge className="mt-4 border-cyan/40 bg-cyan/10 text-cyan">Шууд мэдээлэл (камер)</Badge>
                </>
              ) : (
                <p className="mt-4 rounded-xl border border-line p-3 text-sm text-muted">
                  {cam.detectedAt ? `Энэ камерын тооллого ${hm(cam.detectedAt)}-аас хойш шинэчлэгдээгүй тул одоогийн ачааллыг мэдэх боломжгүй.` : "Энэ камер машин тоолдоггүй, ачааллын мэдээлэл өгдөггүй."} Шууд бичлэгийг нь dedtuv сайтаас харах боломжтой.
                </p>
              )}
              <a href="https://dedtuv.erdenet.mn/live" target="_blank" rel="noopener noreferrer"
                className="mt-4 flex items-center justify-center gap-1.5 rounded-xl bg-cyan/15 px-3 py-2.5 text-sm font-semibold text-cyan hover:bg-cyan/25">Шууд камер харах ↗</a>
              <Button className="mt-2 w-full" variant="ghost" size="sm" onClick={() => askAI(`${cam.name} ачаалалтай юу?`)}><Bot className="h-4 w-4" />AI-аас асуух</Button>
            </div>
          ) : sel ? (
            <div>
              <div className="flex items-start justify-between gap-2">
                <Badge className={STATUS[sel.status].cls}>{STATUS[sel.status].label}</Badge>
                <button type="button" onClick={() => setSelected(null)} className="grid h-7 w-7 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-4 w-4" /></button>
              </div>
              <h3 className="mt-3 text-lg font-semibold">{sel.title}</h3>
              <p className="mt-1 text-xs text-muted">{sel.id} · {ISSUE_CAT[sel.category]}</p>
              <p className="mt-3 text-sm leading-relaxed text-muted">{sel.description}</p>
              <dl className="mt-4 space-y-2 text-sm">
                <div className="flex gap-2"><MapPin className="h-4 w-4 text-cyan" /><dd>{sel.area}</dd></div>
                <div className="flex gap-2"><CalendarDays className="h-4 w-4 text-cyan" /><dd>Мэдээлсэн: {fmtDate(sel.reportedAt)}</dd></div>
                {sel.organization && <div className="text-muted">Хариуцагч: {sel.organization}</div>}
                {sel.action && <div className="rounded-lg border border-emerald/30 bg-emerald/10 p-2.5 text-emerald">{sel.action}</div>}
              </dl>
              <div className="mt-4 flex flex-wrap gap-2"><DemoTag /><DemoTag>Жишээ байршил</DemoTag></div>
              <Button className="mt-4 w-full" variant="ghost" size="sm" onClick={() => askAI(`${sel.area} орчимд ямар асуудал байна?`)}><Bot className="h-4 w-4" />AI-аас асуух</Button>
            </div>
          ) : sp ? (
            <div>
              <div className="flex items-start justify-between gap-2">
                <Badge className="border-emerald/40 bg-emerald/10 text-emerald"><ShieldCheck className="h-3 w-3" />Баталгаатай байршил</Badge>
                <button type="button" onClick={() => setSpot(null)} className="grid h-7 w-7 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-4 w-4" /></button>
              </div>
              <h3 className="mt-3 text-lg font-semibold">{sp.name}</h3>
              <p className="mt-2 text-sm text-muted">{sp.note}</p>
              <p className="mt-3 text-xs text-muted">Эх сурвалж: <a className="text-cyan underline" href="https://dedtuv.erdenet.mn/live" target="_blank" rel="noopener noreferrer">dedtuv.erdenet.mn/live</a>. Байршил: OpenStreetMap.</p>
            </div>
          ) : (
            <div className="flex h-full flex-col">
              {layer === "issues" && (
                <>
                  <h3 className="font-semibold">Тэмдэглэгээ</h3>
                  <ul className="mt-3 space-y-2.5 text-sm">
                    {(["new", "progress", "resolved"] as const).map((s) => (
                      <li key={s} className="flex items-center gap-2.5"><span className="h-3 w-3 rounded-full" style={{ background: STATUS[s].color, boxShadow: `0 0 8px ${STATUS[s].color}` }} />{STATUS[s].label}
                        <span className="ml-auto text-muted">{DEMO_ISSUES.filter((i) => i.status === s).length}</span></li>
                    ))}
                  </ul>
                </>
              )}
              {showTraffic && (
                <>
                  <h3 className="font-semibold">Замын ачаалал (камер)</h3>
                  <ul className="mt-3 space-y-2.5 text-sm">
                    {([[0, "Ачаалалгүй"], [1, "Дунд зэргийн ачаалалтай"], [2, "Ачаалал ихтэй"], [-1, "Мэдээлэлгүй (тооллогогүй)"]] as const).map(([r, l]) => (
                      <li key={r} className="flex items-center gap-2.5"><span className={cn("h-3.5 w-3.5 rounded-full border-[3px] bg-navy", r < 0 && "border-dashed")} style={{ borderColor: trafficColor(r) }} />{l}
                        <span className="ml-auto text-muted">{cameras.filter((c) => (r === 2 ? c.rank >= 2 : c.rank === r)).length}</span></li>
                    ))}
                    <li className="flex items-center gap-2.5"><span className="h-1.5 w-5 rounded-full" style={{ background: "linear-gradient(90deg,#22c55e,#ffc24b,#ff5a6e)" }} />Гол зам: камерын {250} м радиуст өнгөтэй</li>
                    <li className="flex items-center gap-2.5"><span className="h-1 w-5 rounded-full bg-[#64748b] opacity-60" />Камергүй хэсэг (мэдээлэлгүй)</li>
                    <li className="flex items-center gap-2.5"><span className="grid h-4 w-4 place-items-center rounded border border-cyan text-[11px] text-cyan">✓</span>Шалгасан замын цэг (OSM)</li>
                  </ul>
                  {cameras.some((c) => c.rank >= 1) && (
                    <ul className="mt-3 space-y-1 text-sm">
                      {cameras.filter((c) => c.rank >= 1).map((c) => (
                        <li key={c.name}><button type="button" onClick={() => { clear(); setCamName(c.name); }} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left hover:bg-white/5">
                          <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: trafficColor(c.rank) }} /><span className="truncate">{c.name}</span><span className="ml-auto shrink-0 text-xs text-muted">{c.vehicles} машин</span>
                        </button></li>
                      ))}
                    </ul>
                  )}
                </>
              )}
              <p className="mt-5 text-sm text-muted">{layer === "issues" ? "Цэг дээр дарж дэлгэрэнгүйг харна уу. Асуудлын цэгүүд нь жишээ байршил." : "Камер эсвэл өнгөтэй зам дээр дарж дэлгэрэнгүйг харна уу. Баталгаатай байршил зөвхөн ✓ тэмдэгтэй цэгүүд."}</p>
              <ul className="mt-5 space-y-1.5 overflow-y-auto text-sm">
                {issues.slice(0, 6).map((i) => (
                  <li key={i.id}><button type="button" onClick={() => setSelected(i.id)} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left hover:bg-white/5">
                    <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: STATUS[i.status].color }} /><span className="truncate">{i.title}</span><span className="ml-auto shrink-0 text-xs text-muted">{i.area}</span>
                  </button></li>
                ))}
              </ul>
            </div>
          )}
        </Card>
      </div>
    </section>
  );
}
