"use client";

import dynamic from "next/dynamic";
import { CheckCircle2, MapPin, Plus, Radio, Siren, Trash2, X } from "lucide-react";
import { useState } from "react";
import { ALERT_KIND, ALERT_LEVEL, isOpen, type AlertKind, type AlertLevel, type CivicAlert } from "@/lib/civic";
import { useStore } from "@/lib/store";
import { Badge, Button, Card, Empty, Field, SectionHead, cn, inputCls } from "./ui";

const PointPicker = dynamic(() => import("./PointPicker"), { ssr: false, loading: () => <div className="h-56 animate-pulse rounded-xl bg-white/5" /> });

const when = (iso: string | null) => (iso ? new Date(iso).toLocaleString("mn-MN", { timeZone: "Asia/Ulaanbaatar", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }) : "");

/** Thin strip under the header for open critical/warning notices. Each can be hidden for this visit. */
export function AlertBanner() {
  const { alerts } = useStore();
  const [hidden, setHidden] = useState<number[]>([]);
  const urgent = (alerts ?? []).filter((a) => isOpen(a) && a.level !== "info" && !hidden.includes(a.id));
  if (!urgent.length) return null;
  const top = urgent[0];
  const lv = ALERT_LEVEL[top.level];
  return (
    <div role="alert" className="border-b" style={{ background: lv.color + "1f", borderColor: lv.color + "55" }}>
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-2.5 md:px-6">
        <Siren className="h-5 w-5 shrink-0" style={{ color: lv.color }} />
        <a href="#alerts" className="min-w-0 flex-1 text-sm hover:underline">
          <b style={{ color: lv.color }}>{lv.label}:</b> {ALERT_KIND[top.kind].icon} {top.title}{top.area ? ` — ${top.area}` : ""}
          {urgent.length > 1 && <span className="ml-2 text-muted">+{urgent.length - 1} мэдээлэл</span>}
        </a>
        <button type="button" onClick={() => setHidden((h) => [...h, top.id])} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg hover:bg-white/10" aria-label="Энэ мэдээллийг нуух"><X className="h-4 w-4" /></button>
      </div>
    </div>
  );
}

function AlertCard({ a, admin, onChange }: { a: CivicAlert; admin: boolean; onChange: (items: CivicAlert[]) => void }) {
  const { showToast } = useStore();
  const open = isOpen(a);
  const lv = ALERT_LEVEL[a.level];
  const k = ALERT_KIND[a.kind];
  const act = async (action: "close" | "delete") => {
    if (action === "delete" && !window.confirm("Энэ мэдээллийг бүр мөсөн устгах уу?")) return;
    const r = await fetch(`/api/alerts?id=${a.id}&action=${action}`, { method: "DELETE" });
    const d = await r.json();
    if (r.ok) { onChange(d.items); showToast(action === "close" ? "Шийдэгдсэн гэж тэмдэглэлээ" : "Устгалаа"); } else showToast(d.error);
  };
  return (
    <li className={cn("rounded-2xl border p-4", open ? "" : "opacity-60")} style={open ? { borderColor: lv.color + "66", background: lv.color + "0d" } : undefined}>
      <div className="flex flex-wrap items-center gap-2">
        <Badge color={open ? lv.color : "#9fb3c8"}>{open ? lv.label : "Шийдэгдсэн"}</Badge>
        <Badge color={k.color}>{k.icon} {k.label}</Badge>
        {a.lat != null && <span className="flex items-center gap-1 text-xs text-muted"><MapPin className="h-3.5 w-3.5" />Газрын зураг дээр</span>}
      </div>
      <h3 className="mt-2 text-lg font-semibold">{a.title}</h3>
      {a.area && <p className="mt-0.5 text-sm text-muted">{a.area}</p>}
      {a.body && <p className="mt-2 whitespace-pre-line text-[15px] leading-relaxed">{a.body}</p>}
      <p className="mt-2 text-[13px] text-muted">
        {a.startsAt && <>Эхлэх {when(a.startsAt)} · </>}{a.endsAt && <>Дуусах {when(a.endsAt)} · </>}Оруулсан {when(a.createdAt)}
        {a.source && <> · Эх сурвалж: {/^https?:\/\//.test(a.source) ? <a href={a.source} target="_blank" rel="noopener noreferrer" className="text-cyan underline">{a.source.replace(/^https?:\/\//, "").slice(0, 40)}</a> : a.source}</>}
      </p>
      {admin && (
        <div className="mt-3 flex flex-wrap gap-2">
          {open && <Button size="sm" variant="ghost" onClick={() => act("close")}><CheckCircle2 className="h-4 w-4" />Шийдэгдсэн</Button>}
          <Button size="sm" variant="subtle" onClick={() => act("delete")}><Trash2 className="h-4 w-4" />Устгах</Button>
        </div>
      )}
    </li>
  );
}

export function AlertsSection() {
  const { alerts, setAlerts, me, showToast } = useStore();
  const [showClosed, setShowClosed] = useState(false);
  const admin = me?.user?.role === "admin";
  const open = (alerts ?? []).filter((a) => isOpen(a));
  const closed = (alerts ?? []).filter((a) => !isOpen(a));
  return (
    <section id="alerts" className="mx-auto max-w-7xl px-4 py-14 md:py-20 md:px-6" aria-labelledby="alerts-title">
      <SectionHead id="alerts-title" eyebrow="Шуурхай мэдээлэл" title="Яаралтай, шуурхай мэдээлэл"
        lead="Ус, цахилгаан, дулааны тасралт, зам хаалт, онцгой байдлын мэдээллийг нэг дор. Байршилтай тасралтыг газрын зургийн «Тасралт» давхаргаас харна. Хуудас 2 минут тутам шинэчлэгдэнэ." />
      <div className="grid gap-5 lg:grid-cols-[1fr_400px]">
        <Card className="p-5">
          <p className="mb-4 flex items-center gap-2 text-sm font-semibold"><Radio className="h-4 w-4 text-alert" />Идэвхтэй: {alerts ? open.length : "…"}</p>
          {alerts === null ? <div className="h-32 animate-pulse rounded-xl bg-white/5" /> : open.length ? (
            <ul className="grid gap-3">{open.map((a) => <AlertCard key={a.id} a={a} admin={admin} onChange={setAlerts} />)}</ul>
          ) : (
            <Empty title="Одоогоор шуурхай мэдээлэл алга" text="Ус, цахилгаан тасрах, онцгой нөхцөл байдал үүсвэл энд болон хуудасны дээд хэсэгт шууд гарна." />
          )}
          {closed.length > 0 && (
            <div className="mt-5">
              <button type="button" className="text-sm font-semibold text-cyan" onClick={() => setShowClosed((s) => !s)} aria-expanded={showClosed}>
                {showClosed ? "Шийдэгдсэнийг нуух" : `Шийдэгдсэн / дууссан (${closed.length})`}
              </button>
              {showClosed && <ul className="mt-3 grid gap-3">{closed.map((a) => <AlertCard key={a.id} a={a} admin={admin} onChange={setAlerts} />)}</ul>}
            </div>
          )}
          <p className="mt-5 rounded-xl border border-line p-3 text-sm text-muted">Амь нас, эд хөрөнгөд аюул тулгарвал: <b className="text-snow">101</b> гал, <b className="text-snow">102</b> цагдаа, <b className="text-snow">103</b> түргэн тусламж, <b className="text-snow">105</b> онцгой байдал.</p>
        </Card>
        {admin ? <AlertForm onSaved={(it) => { setAlerts(it); showToast("Шуурхай мэдээлэл нийтлэгдлээ"); }} /> : (
          <Card className="p-5 text-sm text-muted">
            <h3 className="mb-2 font-semibold text-snow">Хэн оруулах вэ?</h3>
            <p>Буруу мэдээлэл олон хүнийг төөрөгдүүлэх тул шуурхай мэдээллийг зөвхөн <b className="text-snow">админ</b> албан ёсны эх сурвалжтайгаар (Эрдэнэт Ус, ЦТС, Онцгой байдлын газар г.м.) оруулна.</p>
            <p className="mt-3">Та асуудал анзаарвал «Асуудал мэдээлэх» хэсгээр илгээнэ үү.</p>
          </Card>
        )}
      </div>
    </section>
  );
}

function AlertForm({ onSaved }: { onSaved: (items: CivicAlert[]) => void }) {
  const [level, setLevel] = useState<AlertLevel>("warning");
  const [kind, setKind] = useState<AlertKind>("water");
  const [title, setTitle] = useState("");
  const [area, setArea] = useState("");
  const [body, setBody] = useState("");
  const [startsAt, setStarts] = useState("");
  const [endsAt, setEnds] = useState("");
  const [source, setSource] = useState("");
  const [point, setPoint] = useState<[number, number] | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  // datetime-local has no zone; the city runs on Ulaanbaatar time (+08:00).
  const iso = (v: string) => (v ? `${v}:00+08:00` : "");

  async function save(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (!title.trim()) { setErr("Гарчиг бичнэ үү."); return; }
    setBusy(true);
    try {
      const r = await fetch("/api/alerts", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ level, kind, title, area, body, startsAt: iso(startsAt), endsAt: iso(endsAt), source, lat: point?.[0], lng: point?.[1] }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      onSaved(d.items); setTitle(""); setBody(""); setArea(""); setPoint(null); setStarts(""); setEnds("");
    } catch (ex) { setErr(ex instanceof Error ? ex.message : "Хадгалж чадсангүй."); } finally { setBusy(false); }
  }

  return (
    <Card className="p-5">
      <h3 className="mb-3 flex items-center gap-2 font-semibold"><Plus className="h-4 w-4 text-cyan" />Шуурхай мэдээлэл нийтлэх (админ)</h3>
      <form onSubmit={save} className="grid gap-3">
        <div className="grid grid-cols-2 gap-2">
          <Field label="Түвшин" htmlFor="a-level"><select id="a-level" className={inputCls} value={level} onChange={(e) => setLevel(e.target.value as AlertLevel)}>{(Object.keys(ALERT_LEVEL) as AlertLevel[]).map((k) => <option key={k} value={k}>{ALERT_LEVEL[k].label}</option>)}</select></Field>
          <Field label="Төрөл" htmlFor="a-kind"><select id="a-kind" className={inputCls} value={kind} onChange={(e) => setKind(e.target.value as AlertKind)}>{(Object.keys(ALERT_KIND) as AlertKind[]).map((k) => <option key={k} value={k}>{ALERT_KIND[k].icon} {ALERT_KIND[k].label}</option>)}</select></Field>
        </div>
        <Field label="Гарчиг" htmlFor="a-title"><input id="a-title" className={inputCls} value={title} maxLength={140} onChange={(e) => setTitle(e.target.value)} placeholder="Жишээ: 3-р микрод хүйтэн ус түр тасарна" /></Field>
        <Field label="Хамрах бүс" htmlFor="a-area"><input id="a-area" className={inputCls} value={area} maxLength={140} onChange={(e) => setArea(e.target.value)} placeholder="Жишээ: 3-р микро, 12-р баг" /></Field>
        <Field label="Дэлгэрэнгүй" htmlFor="a-body"><textarea id="a-body" rows={3} className={inputCls} value={body} maxLength={1000} onChange={(e) => setBody(e.target.value)} placeholder="Шалтгаан, иргэд юу хийх, хаана хандах" /></Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Эхлэх" htmlFor="a-start"><input id="a-start" type="datetime-local" className={inputCls} value={startsAt} onChange={(e) => setStarts(e.target.value)} /></Field>
          <Field label="Дуусах (таамаг)" htmlFor="a-end"><input id="a-end" type="datetime-local" className={inputCls} value={endsAt} onChange={(e) => setEnds(e.target.value)} /></Field>
        </div>
        <div>
          <p className="mb-1.5 text-sm font-semibold">Газрын зураг дээрх байршил <span className="font-normal text-muted">(дарж сонгоно, заавал биш)</span></p>
          <PointPicker value={point} onPick={setPoint} />
          {point && <p className="mt-1 flex items-center justify-between text-xs text-muted">{point[0]}, {point[1]}<button type="button" className="text-cyan" onClick={() => setPoint(null)}>Арилгах</button></p>}
        </div>
        <Field label="Эх сурвалж" htmlFor="a-src"><input id="a-src" className={inputCls} value={source} maxLength={300} onChange={(e) => setSource(e.target.value)} placeholder="Байгууллагын нэр эсвэл холбоос" /></Field>
        {err && <p className="text-sm text-alert" role="alert">{err}</p>}
        <Button type="submit" disabled={busy}>{busy ? "Нийтэлж байна…" : "Нийтлэх"}</Button>
      </form>
    </Card>
  );
}
