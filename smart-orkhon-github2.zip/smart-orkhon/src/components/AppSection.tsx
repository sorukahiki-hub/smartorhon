import QRCode from "qrcode";
import { Bell, Bus, CloudSun, Megaphone, Siren, Smartphone, WifiOff, Zap } from "lucide-react";
import { TABS } from "@/lib/appNav";
import { Logo } from "./Header";
import { InstallPanel } from "./InstallPanel";
import { SectionHead } from "./ui";

const SITE = process.env.NEXT_PUBLIC_SITE_URL || "https://smart-orkhon.vercel.app";

// QR code drawn as one SVG path on the server, so the QR library never reaches the browser.
function qrPath(text: string) {
  const { modules } = QRCode.create(text, { errorCorrectionLevel: "M" });
  let d = "";
  for (let y = 0; y < modules.size; y++) for (let x = 0; x < modules.size; x++) if (modules.get(y, x)) d += `M${x} ${y}h1v1h-1z`;
  return { d, size: modules.size };
}

const PERKS = [
  { icon: Zap, t: "Нэг товшилтоор нээгдэнэ", d: "Нүүр дэлгэцэн дээрх дүрсээс шууд, хөтчийн мөргүй бүтэн дэлгэцээр." },
  { icon: Siren, t: "Шуурхай мэдээ, автобус, үйлчилгээ", d: "Сайтын бүх мэдээлэл аппад ижилхэн, үргэлж хамгийн сүүлийн хувилбараар." },
  { icon: WifiOff, t: "Сүлжээгүй үед ч нээгдэнэ", d: "Сүүлд ачаалсан хуудас хадгалагдана. Шинэ мэдээ холболт орж ирэхэд шинэчлэгдэнэ." },
  { icon: Smartphone, t: "Хөнгөн, үнэгүй", d: "Санах ой бага эзэлнэ. App Store, Google Play-гүйгээр шууд суулгана." },
];

/** A phone frame drawn with the site's own colours and components: the design of the app. */
function Phone({ title, children, tab, className = "" }: { title: string; children: React.ReactNode; tab: string; className?: string }) {
  return (
    <div className={`relative w-[230px] shrink-0 rounded-[2.4rem] border border-white/15 bg-[#030a14] p-2 shadow-[0_40px_80px_-30px_rgba(0,229,255,.45)] ${className}`} aria-hidden="true">
      <div className="relative flex h-[470px] flex-col overflow-hidden rounded-[2rem] bg-navy bg-grid">
        <div className="absolute left-1/2 top-2 h-5 w-20 -translate-x-1/2 rounded-full bg-black" />
        <div className="flex items-center justify-between px-5 pt-2 text-[10px] font-semibold text-snow/80"><span>9:41</span><span>5G ▮▮▮</span></div>
        <div className="mt-3 flex items-center gap-2 border-b border-line px-3 pb-2">
          <span className="scale-75"><Logo /></span>
          <span className="flex-1 leading-tight"><span className="block text-[11px] font-bold">SMART ORKHON</span><span className="block text-[9px] text-muted">{title}</span></span>
          <span className="grid h-7 w-7 place-items-center rounded-lg border border-line"><Bell className="h-3.5 w-3.5" /></span>
        </div>
        <div className="flex-1 space-y-2 overflow-hidden p-3 text-[10.5px] leading-snug">{children}</div>
        <div className="grid h-12 grid-cols-5 border-t border-line bg-navy/90 text-[8.5px] font-semibold text-muted">
          {TABS.map(({ href, label, icon: I, primary }) => (
            <span key={href} className={`flex flex-col items-center justify-center gap-0.5 ${tab === href ? "text-cyan" : ""}`}>
              {primary ? <span className="-mt-4 grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-cyan to-emerald text-navy"><I className="h-4 w-4" /></span> : <I className="h-3.5 w-3.5" />}{label}
            </span>
          ))}
          <span className="flex flex-col items-center justify-center gap-0.5"><span className="grid h-3.5 w-3.5 grid-cols-2 gap-px">{[0, 1, 2, 3].map((i) => <i key={i} className="rounded-[1px] border border-current" />)}</span>Цэс</span>
        </div>
      </div>
    </div>
  );
}

const Tile = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => <div className={`glass rounded-xl p-2.5 ${className}`}>{children}</div>;

export function AppSection() {
  const qr = qrPath(SITE);
  return (
    <section id="app" className="border-y border-line bg-navy-2/60 py-14 md:py-20" aria-labelledby="app-title">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 md:px-6 lg:grid-cols-[1fr_auto]">
        <div>
          <SectionHead id="app-title" eyebrow="Гар утасны апп" title="«Ухаалаг Орхон» аппыг утсандаа суулгаарай"
            lead="Сайтын бүх боломж утсанд тань апп хэлбэрээр. Доорх товчоор эсвэл заавраар 10 секундэд суулгана." />
          <ul className="mb-6 grid gap-3 sm:grid-cols-2">
            {PERKS.map(({ icon: I, t, d }) => (
              <li key={t} className="flex gap-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-cyan/10 text-cyan"><I className="h-[18px] w-[18px]" /></span>
                <span><b className="block text-sm">{t}</b><span className="text-sm text-muted">{d}</span></span>
              </li>
            ))}
          </ul>
          <div className="grid gap-4 sm:grid-cols-[1fr_auto] sm:items-start">
            <InstallPanel />
            <div className="hidden flex-col items-center gap-2 sm:flex">
              <svg viewBox={`-2 -2 ${qr.size + 4} ${qr.size + 4}`} className="h-36 w-36 rounded-xl bg-white" role="img" aria-label={`${SITE} хаягийн QR код`}>
                <path d={qr.d} fill="#061322" shapeRendering="crispEdges" />
              </svg>
              <p className="text-xs text-muted">Утсаараа уншуулна уу</p>
            </div>
          </div>
          <p className="mt-4 text-[13px] text-muted">App Store, Google Play дэлгүүрийн хувилбар бэлтгэгдэж байна. Одоогийн апп нь дэлгүүрийн хувилбартай ижил агуулгатай бөгөөд шинэчлэл автоматаар ирнэ.</p>
        </div>

        <div className="relative mx-auto flex justify-center lg:mx-0">
          <Phone title="Ухаалаг Орхон" tab="#home" className="z-10 -rotate-3">
            <div className="rounded-xl border border-alert/40 bg-alert/10 p-2"><p className="flex items-center gap-1 font-bold text-alert"><Siren className="h-3 w-3" />Шуурхай мэдээ</p><p className="mt-0.5 text-snow/90">Ус, цахилгаан, дулааны тасралт энд гарна</p></div>
            <Tile className="flex items-center gap-2"><CloudSun className="h-5 w-5 text-warn" /><span><b className="block text-[12px]">Эрдэнэт</b><span className="text-muted">Цаг агаар · 7 хоног</span></span></Tile>
            <div className="grid grid-cols-2 gap-2">
              {[[Bell, "Мэдэгдэл"], [Megaphone, "Мэдээлэх"], [Bus, "Автобус"], [Smartphone, "Үйлчилгээ"]].map(([I, l]) => {
                const Icon = I as typeof Bell;
                return <Tile key={l as string} className="flex flex-col items-start gap-1"><Icon className="h-4 w-4 text-cyan" /><b>{l as string}</b></Tile>;
              })}
            </div>
            <Tile><p className="font-semibold">Орхон AI туслах</p><p className="text-muted">«Ус хэзээ ирэх вэ?» гэж асуугаарай</p></Tile>
          </Phone>
          <Phone title="Автобус" tab="#bus" className="-ml-16 mt-12 hidden rotate-3 sm:block">
            <Tile><p className="text-muted">Хаанаас</p><b>Уртын гол</b><p className="mt-1 text-muted">Хаашаа</p><b>Даниста</b></Tile>
            <Tile>
              <div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-lg bg-cyan font-extrabold text-navy">Ч8</span><b>Даниста – Уртын гол</b></div>
              <p className="mt-1.5 text-muted">07:00 · 07:30 · 08:00 · 08:30 …</p>
              <ol className="mt-1.5 space-y-0.5 border-l-2 border-line pl-2">
                <li className="font-bold text-cyan">Даниста · Буух</li><li className="text-muted">Мэнд-Амар</li><li className="text-muted">…</li><li className="font-bold text-cyan">Уртын гол баг · Суух</li>
              </ol>
            </Tile>
          </Phone>
        </div>
      </div>
    </section>
  );
}
