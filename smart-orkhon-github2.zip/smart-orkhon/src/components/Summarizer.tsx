"use client";

import { CheckSquare, FileText, Loader2, Sparkles } from "lucide-react";
import { useState } from "react";
import { Badge, Button, Card, SectionHead, inputCls } from "./ui";

interface Summary { what: string; where: string; when: string; who: string; todo: string; simple: string }

const SAMPLE = `ЖИШЭЭ ЗАР. "Эрдэнэт Ус" ОНӨҮГ нь цэвэр усны шугам сүлжээний найдвартай ажиллагааг хангах зорилгоор 3-р микрын 12, 14, 16-р байрыг хамарсан магистраль шугамын хаалт, хавхлага солих төлөвлөгөөт засварын ажлыг 2026 оны 11-р сарын 24-ний өдөр 10:00-16:00 цагийн хооронд гүйцэтгэх тул дээрх хугацаанд цэвэр усны хангамж түр зогсохыг хэрэглэгчиддээ мэдэгдэж байна. Иргэд усаа урьдчилан нөөцлөхийг хүсье.`;

export function Summarizer() {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<{ summary: Summary; mode: string; model?: string; warning?: string } | null>(null);
  const [error, setError] = useState("");
  const [reviewed, setReviewed] = useState(false);

  async function run() {
    setError(""); setRes(null); setReviewed(false);
    if (text.trim().length < 30) { setError("Зарын текстийг 30-аас дээш тэмдэгтээр оруулна уу."); return; }
    setBusy(true);
    try {
      const r = await fetch("/api/summarize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Алдаа гарлаа.");
      setRes(d);
    } catch (e) { setError(e instanceof Error ? e.message : "Алдаа гарлаа."); } finally { setBusy(false); }
  }

  const rows: [keyof Summary, string][] = [["what", "Юу болох"], ["where", "Хаана"], ["when", "Хэзээ"], ["who", "Хэнд нөлөөлөх"], ["todo", "Иргэд юу хийх"]];

  return (
    <section id="summarizer" className="mx-auto max-w-7xl px-4 py-14 md:py-20 md:px-6" aria-labelledby="sum-title">
      <SectionHead id="sum-title" eyebrow="AI хураангуйлагч" title="Урт зарыг энгийн хэлээр"
        lead="Албан ёсны урт зарыг буулгахад юу, хаана, хэзээ, хэнд, юу хийх гэж 5 мөрөөр тайлбарлана. Зарт байхгүй зүйлийг таамаглахгүй." />
      <ol className="mb-5 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted">
        {["Зарын текстийг буулгана", "«Хураангуйлах» дарна", "Энгийн тайлбарыг эх зартай тулгана"].map((t, i) => (
          <li key={t} className="flex items-center gap-2"><span className="grid h-6 w-6 place-items-center rounded-full bg-cyan/15 text-xs font-bold text-cyan">{i + 1}</span>{t}</li>
        ))}
      </ol>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="flex flex-col p-5">
          <div className="mb-3 flex items-center justify-between"><p className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4 text-cyan" />Эх зар</p>
            <button type="button" className="text-xs font-semibold text-cyan hover:underline" onClick={() => setText(SAMPLE)}>Жишээ зар оруулах</button></div>
          <label htmlFor="sum-text" className="sr-only">Зарын текст</label>
          <textarea id="sum-text" rows={7} className={`${inputCls} flex-1`} value={text} onChange={(e) => setText(e.target.value)} maxLength={6000} placeholder="Албан ёсны зарын текстийг энд буулгана уу…" />
          {error && <p className="mt-2 text-sm text-alert" role="alert">{error}</p>}
          <Button className="mt-3" onClick={run} disabled={busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}{busy ? "Боловсруулж байна…" : "Хураангуйлах"}</Button>
        </Card>
        <Card className={res ? "p-5" : "hidden p-5 lg:block"} aria-live="polite">
          {res ? (
            <div>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <Badge className={res.mode === "gemini" ? "border-cyan/40 bg-cyan/10 text-cyan" : "border-warn/40 bg-warn/10 text-warn"}>
                  {res.mode === "gemini" ? `Gemini (${res.model})` : "Демо горим: дүрмээр ялгасан, Gemini биш"}
                </Badge>
                <Badge className={reviewed ? "border-emerald/40 bg-emerald/10 text-emerald" : "border-alert/40 bg-alert/10 text-alert"}>{reviewed ? "Хянасан" : "Хянаагүй AI хураангуй"}</Badge>
              </div>
              {res.warning && <p className="mb-3 text-xs text-warn">{res.warning}</p>}
              <div className="rounded-xl border border-emerald/30 bg-emerald/[.08] p-4"><p className="text-[12.5px] font-bold uppercase tracking-wider text-emerald">Энгийн хураангуй</p><p className="mt-1 text-[15px] leading-relaxed">{res.summary.simple}</p></div>
              <dl className="mt-4 grid gap-2 sm:grid-cols-2">
                {rows.map(([k, l]) => (
                  <div key={k} className="rounded-xl border border-line p-3"><dt className="text-[12.5px] text-muted">{l}</dt><dd className={`text-sm ${res.summary[k] === "Зарт дурдаагүй" ? "text-muted italic" : ""}`}>{res.summary[k]}</dd></div>
                ))}
              </dl>
              <label className="mt-4 flex cursor-pointer items-start gap-2 rounded-xl border border-line p-3 text-sm">
                <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#00d9a5]" checked={reviewed} onChange={(e) => setReviewed(e.target.checked)} />
                <span>Хураангуйг эх зартай тулгаж шалгасан. Баталгаажсан мэдээлэл болгон нийтлэхээс өмнө ажилтан заавал хянана.</span>
              </label>
              <Button className="mt-3 w-full" variant="emerald" disabled={!reviewed} onClick={() => alertPublish()}><CheckSquare className="h-4 w-4" />Нийтлэхэд бэлэн гэж тэмдэглэх</Button>
            </div>
          ) : (
            <div className="grid h-full min-h-64 place-items-center text-center text-sm text-muted">
              <div><Sparkles className="mx-auto mb-2 h-8 w-8 text-cyan/60" />Зүүн талд зарын текстийг оруулаад «Хураангуйлах» дарна уу.<br />Эх зар болон хураангуй зэрэгцэн харагдана.</div>
            </div>
          )}
        </Card>
      </div>
    </section>
  );

  function alertPublish() {
    setRes((r) => (r ? { ...r, warning: "Туршилтын горим: нийтлэх систем холбогдоогүй. Хянасан хураангуйг админ самбараар нийтлэх боломжтой болно." } : r));
  }
}
