import type { Metadata, Viewport } from "next";
import { Inter, Manrope } from "next/font/google";
import "leaflet/dist/leaflet.css";
import "./globals.css";

// Mongolian needs Ө ө Ү ү (cyrillic-ext) and ₮. Both fonts were checked to contain every one of them;
// the previous heading font (Unbounded) lacked Ө/Ү/₮, so those letters fell back to another font mid-word.
const inter = Inter({ variable: "--font-inter", subsets: ["latin", "cyrillic", "cyrillic-ext"], display: "swap" });
const display = Manrope({ variable: "--font-display", subsets: ["latin", "cyrillic", "cyrillic-ext"], weight: ["500", "600", "700", "800"], display: "swap" });

export const metadata: Metadata = {
  title: "SMART ORKHON — Ухаалаг Орхон",
  description: "Орхон аймгийн мэдэгдэл, иргэдийн асуудал, шийдэл, AI туслахыг нэг дор холбосон иргэний технологийн платформ.",
  applicationName: "Ухаалаг Орхон",
  appleWebApp: { capable: true, title: "Ухаалаг Орхон", statusBarStyle: "black-translucent" },
  icons: { icon: [{ url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }], apple: "/icons/apple-touch-icon.png" },
};

// viewportFit "cover" lets the installed app use the whole screen; the bottom bar adds the safe-area padding itself.
export const viewport: Viewport = { themeColor: "#061322", viewportFit: "cover" };

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="mn" className={`${inter.variable} ${display.variable} h-full antialiased`}>
      <body className="min-h-full bg-navy pb-[calc(4rem+env(safe-area-inset-bottom))] text-snow md:pb-0">{children}</body>
    </html>
  );
}
