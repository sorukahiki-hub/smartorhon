import { listBus } from "@/lib/server/alerts";
import { currentUser } from "@/lib/server/auth";
import { nowIso, run } from "@/lib/server/db";
import { cleanText } from "@/lib/server/guard";

export async function GET() {
  return Response.json({ items: await listBus() });
}

const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;
const money = (v: unknown) => (typeof v === "number" && Number.isInteger(v) && v >= 0 && v <= 100_000 ? v : null);

// Routes and fares come only from admins with an official source: a wrong fare or stop misleads riders.
export async function POST(req: Request) {
  const user = await currentUser();
  if (user?.role !== "admin") return Response.json({ error: "Зөвхөн админ чиглэл оруулна." }, { status: 403 });
  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return Response.json({ error: "Хүсэлт буруу байна." }, { status: 400 }); }
  const number = cleanText(b.number, 12);
  const name = cleanText(b.name, 120) || null;
  const stops = (typeof b.stops === "string" ? b.stops : "").split(/\r?\n/).map((s) => cleanText(s, 80) ?? "").filter(Boolean).slice(0, 60);
  const firstTime = typeof b.firstTime === "string" && TIME.test(b.firstTime) ? b.firstTime : null;
  const lastTime = typeof b.lastTime === "string" && TIME.test(b.lastTime) ? b.lastTime : null;
  const interval = typeof b.intervalMin === "number" && Number.isInteger(b.intervalMin) && b.intervalMin > 0 && b.intervalMin <= 240 ? b.intervalMin : null;
  const fareNote = cleanText(b.fareNote, 200) || null;
  const source = cleanText(b.source, 300) || null;
  if (!number || stops.length < 2) return Response.json({ error: "Чиглэлийн дугаар, дор хаяж 2 зогсоол (мөр бүрт нэг) оруулна." }, { status: 400 });
  await run("INSERT INTO bus_routes (number, name, stops, first_time, last_time, interval_min, fare_adult, fare_child, fare_note, source, created_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    number, name, stops.join("\n"), firstTime, lastTime, interval, money(b.fareAdult), money(b.fareChild), fareNote, source, user.id, nowIso());
  return Response.json({ items: await listBus() });
}

export async function DELETE(req: Request) {
  const user = await currentUser();
  if (user?.role !== "admin") return Response.json({ error: "Зөвхөн админ устгана." }, { status: 403 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) return Response.json({ error: "id буруу." }, { status: 400 });
  await run("DELETE FROM bus_routes WHERE id = ?", id);
  return Response.json({ items: await listBus() });
}
