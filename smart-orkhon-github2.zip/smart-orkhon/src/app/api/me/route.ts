import { currentUser } from "@/lib/server/auth";
import { all, run } from "@/lib/server/db";

// The signed-in user plus their own saved questions and reports.
export async function GET() {
  const user = await currentUser();
  if (!user) return Response.json({ user: null });
  const [questions, reports] = await Promise.all([
    all("SELECT question, mode, created_at AS at FROM chat_logs WHERE user_id = ? ORDER BY id DESC LIMIT 30", user.id),
    all("SELECT tracking, title, category, status, created_at AS at FROM reports WHERE user_id = ? ORDER BY created_at DESC LIMIT 30", user.id),
  ]);
  return Response.json({ user, questions, reports });
}

// Let a user delete their own question history.
export async function DELETE() {
  const user = await currentUser();
  if (!user) return Response.json({ error: "Нэвтэрнэ үү." }, { status: 401 });
  await run("DELETE FROM chat_logs WHERE user_id = ?", user.id);
  return Response.json({ ok: true });
}
