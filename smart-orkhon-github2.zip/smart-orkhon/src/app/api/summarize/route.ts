import { callGemini, cleanText, clientKey, geminiErrorMessage, rateLimit, scrubPersonal } from "@/lib/server/guard";

export interface SummaryFields { what: string; where: string; when: string; who: string; todo: string; simple: string }

const SYSTEM = `Чи албан ёсны зарыг энгийн монгол хэлээр хураангуйлдаг туслах.
Зөвхөн өгсөн текстэд байгаа мэдээллийг ашигла. Огноо, цаг, байршил, байгууллагыг ХЭЗЭЭ Ч таамаглаж, зохиож болохгүй.
Текстэд байхгүй талбарт яг "Зарт дурдаагүй" гэж бич.
Зөвхөн дараах JSON-оор хариул: {"what":"Юу болох","where":"Хаана","when":"Хэзээ","who":"Хэнд нөлөөлөх","todo":"Иргэд юу хийх","simple":"1-2 өгүүлбэр энгийн хураангуй"}`;

const NOT = "Зарт дурдаагүй";

// Rule-based extraction for demo mode: copies only what appears literally in the text.
function demoSummary(t: string): SummaryFields {
  const times = t.match(/\b([01]?\d|2[0-3])[:.][0-5]\d\b/g) || [];
  const dates = t.match(/\b(20\d{2}[./-]\d{1,2}[./-]\d{1,2}|\d{1,2}\s*(?:-?р сарын|сарын)\s*\d{1,2}(?:-?ны|-?ний|-нд)?)/gi) || [];
  const where = t.match(/([0-9]+-р\s+(?:баг|микро|хороолол)|[А-ЯӨҮЁ][а-яөүё]+\s+(?:баг|хороолол|гудамж|сум))/gu) || [];
  const water = /ус\b|усны|ус түр/i.test(t), power = /цахилгаан/i.test(t), road = /зам\b|замын|гүүр/i.test(t);
  const what = water ? "Цэвэр усны хангамж түр зогсоно" : power ? "Цахилгаан түр тасарна" : road ? "Замын хөдөлгөөнд өөрчлөлт орно" : NOT;
  const when = [dates.join(", "), times.length >= 2 ? `${times[0]}–${times[1]}` : times[0]].filter(Boolean).join(" ") || NOT;
  const todo = /нөөцл/i.test(t) ? "Усаа урьдчилан нөөцлөх" : /тойруу/i.test(t) ? "Тойруу замаар явах" : NOT;
  const whereS = [...new Set(where)].join(", ") || NOT;
  const simple = what === NOT ? "Зарын гол утгыг автоматаар тодорхойлж чадсангүй. Эх зарыг уншина уу." :
    `${whereS !== NOT ? whereS + "-д " : ""}${when !== NOT ? when + " " : ""}${what.toLowerCase()}.${todo !== NOT ? " " + todo + "." : ""}`;
  return { what, where: whereS, when, who: whereS !== NOT ? `${whereS}-ийн оршин суугчид` : NOT, todo, simple };
}

export async function POST(req: Request) {
  const rl = rateLimit("sum:" + clientKey(req), 6, 60_000);
  if (!rl.ok) return Response.json({ error: `Хэт олон хүсэлт. ${rl.retryAfter} секундын дараа оролдоно уу.` }, { status: 429 });
  let body: { text?: unknown };
  try { body = await req.json(); } catch { return Response.json({ error: "Хүсэлт буруу байна." }, { status: 400 }); }
  const text = cleanText(body.text, 6000);
  if (!text || text.length < 30) return Response.json({ error: "Зарын текст 30–6000 тэмдэгт байх ёстой." }, { status: 400 });

  if (!process.env.GEMINI_API_KEY) return Response.json({ summary: demoSummary(text), mode: "demo" });
  try {
    const { text: raw, model } = await callGemini(SYSTEM, [{ role: "user", text: scrubPersonal(text) }], true);
    const parsed = JSON.parse(raw.replace(/^```json\s*|```$/g, "")) as Partial<SummaryFields>;
    const f = (k: keyof SummaryFields) => (typeof parsed[k] === "string" && parsed[k] ? String(parsed[k]).slice(0, 400) : NOT);
    return Response.json({ summary: { what: f("what"), where: f("where"), when: f("when"), who: f("who"), todo: f("todo"), simple: f("simple") }, mode: "gemini", model });
  } catch (e) {
    const code = e instanceof Error ? e.message : "ERR";
    return Response.json({ summary: demoSummary(text), mode: "demo", warning: code.startsWith("Unexpected") || e instanceof SyntaxError ? "Gemini-ийн хариуг уншиж чадсангүй." : geminiErrorMessage(code) });
  }
}
