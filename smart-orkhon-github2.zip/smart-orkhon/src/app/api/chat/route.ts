import { buildContext, SYSTEM_PROMPT } from "@/lib/server/knowledge";
import { demoAnswer } from "@/lib/server/demoBot";
import { busQuestionHint } from "@/lib/server/alerts";
import { isTrafficQuestion, trafficAnswer } from "@/lib/integrations/traffic";
import { currentUser } from "@/lib/server/auth";
import { batch, bump, nowIso } from "@/lib/server/db";
import { callGemini, cleanText, clientKey, geminiErrorMessage, rateLimit, scrubPersonal } from "@/lib/server/guard";

// Earlier turns longer than this are cut, not rejected.
const HISTORY_MAX = 2000;

export async function POST(req: Request) {
  const rl = rateLimit("chat:" + clientKey(req), 12, 60_000);
  if (!rl.ok) return Response.json({ error: `Хэт олон хүсэлт илгээлээ. ${rl.retryAfter} секундын дараа дахин оролдоно уу.` }, { status: 429 });

  let body: unknown;
  try { body = await req.json(); } catch { return Response.json({ error: "Хүсэлт буруу байна." }, { status: 400 }); }
  const b = body as { messages?: unknown; area?: unknown };
  if (!Array.isArray(b.messages) || b.messages.length === 0 || b.messages.length > 20) {
    return Response.json({ error: "Мессеж буруу байна." }, { status: 400 });
  }
  // Only the new question has a hard length limit. Earlier turns are context: the assistant's own replies are
  // often longer than 1200 characters, and rejecting them used to break the chat for good after one long answer.
  const raw = b.messages.slice(-10) as { role?: unknown; text?: unknown }[];
  const last = raw[raw.length - 1];
  if (last.role !== "user") return Response.json({ error: "Сүүлийн мессеж хэрэглэгчийнх байх ёстой." }, { status: 400 });
  if (!cleanText(last.text, 1200)) return Response.json({ error: "Асуулт хоосон эсвэл хэт урт байна (1200 тэмдэгтээс бага)." }, { status: 400 });
  const msgs: { role: "user" | "model"; text: string }[] = [];
  for (const mm of raw) {
    if (mm.role !== "user" && mm.role !== "assistant") continue;
    const text = cleanText(typeof mm.text === "string" ? mm.text.slice(0, HISTORY_MAX) : mm.text, HISTORY_MAX);
    if (!text) continue;
    const role = mm.role === "user" ? "user" : "model";
    const clean = role === "user" ? scrubPersonal(text) : text;
    // Keep turns alternating (a failed request leaves two user turns in a row) and start with the user.
    const prev = msgs[msgs.length - 1];
    if (prev?.role === role) prev.text += "\n\n" + clean;
    else if (msgs.length || role === "user") msgs.push({ role, text: clean });
  }
  const area = cleanText(b.area, 60) || undefined;

  const question = scrubPersonal(cleanText(last.text, 1200)!);
  const [{ text: baseCtx, anns, traffic }, hint] = await Promise.all([buildContext(), busQuestionHint(question).catch(() => "")]);
  const ctx = hint ? `${hint}\n\n${baseCtx}` : baseCtx;
  // Without Gemini, traffic questions still get the real camera data (rule-based, labelled "live").
  const fallback = () => (isTrafficQuestion(question) ? { reply: trafficAnswer(traffic), mode: "live" } : { reply: demoAnswer(question, anns, area), mode: "demo" });

  // Save the question (personal numbers already scrubbed) for history and statistics. Never blocks the reply.
  const user = await currentUser().catch(() => null);
  const log = (mode: string, model?: string) => {
    return batch([
      { sql: "INSERT INTO chat_logs (user_id, question, mode, model, area, created_at) VALUES (?, ?, ?, ?, ?, ?)", args: [user?.id ?? null, question, mode, model ?? null, area ?? null, nowIso()] },
      bump("questions"),
    ]).catch((err) => console.error("[chat] log failed:", err instanceof Error ? err.message : err));
  };

  if (!process.env.GEMINI_API_KEY) { const f = fallback(); await log(f.mode); return Response.json(f); }
  try {
    const system = `${SYSTEM_PROMPT}\n\nХэрэглэгчийн сонгосон байршил: ${area || user?.area || "сонгоогүй"}.\n\nКОНТЕКСТ:\n${ctx}`;
    const { text: reply, model } = await callGemini(system, msgs);
    await log("gemini", model);
    return Response.json({ reply, mode: "gemini", model });
  } catch (e) {
    const code = e instanceof Error ? e.message : "ERR";
    const f = fallback(); await log(f.mode);
    return Response.json({ ...f, warning: geminiErrorMessage(code) });
  }
}
