// Builds road-following geometry for bus routes from ordered stop coordinates via the public OSRM demo,
// simplifies it and prints a TS array. Usage: node make-bus-geo.cjs > out.txt
const STOPS = [
  ["Кувейтын тойрог", 49.02401, 104.04704],
  ["Даниста", 49.02551, 104.04718],
  ["Мэнд-Амар", 49.02708, 104.04243],
  ["Их хаадын цуваа", 49.0263, 104.035],
  ["Сансар ХТ", 49.02049, 104.0329],
  ["Цагаан худаг", 49.01946, 104.02119],
  ["Петровис ШТС", 48.99049, 104.0217],
  ["20-р сургууль", 48.99384, 104.03023],
  ["Пинк", 48.99644, 104.0321],
  ["Сансар ХТ (буцах)", 49.02049, 104.0329],
  ["14-р сургууль", 49.02432, 104.04353],
  ["Кувейтын тойрог (эцэс)", 49.02401, 104.04704],
];
// Leg index -> which OSRM alternative to use. Leg 8 (Пинк → Сансар): the fastest route runs up to the Kuwait
// roundabout and doubles back; the official schematic goes north-west and rejoins the main road, i.e. alternative 1.
const PICK = { 8: 1 };

const m = (a, b) => Math.hypot((a[0] - b[0]) * 111320, (a[1] - b[1]) * 73030);
function segDist(p, a, b) {
  const ax = a[1] * 73030, ay = a[0] * 111320, bx = b[1] * 73030, by = b[0] * 111320, px = p[1] * 73030, py = p[0] * 111320;
  const dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
  const t = L ? Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / L)) : 0;
  return Math.hypot(px - ax - t * dx, py - ay - t * dy);
}
function simplify(pts, tol) {
  if (pts.length < 3) return pts;
  let idx = 0, max = 0;
  for (let i = 1; i < pts.length - 1; i++) { const d = segDist(pts[i], pts[0], pts[pts.length - 1]); if (d > max) { max = d; idx = i; } }
  if (max <= tol) return [pts[0], pts[pts.length - 1]];
  return [...simplify(pts.slice(0, idx + 1), tol).slice(0, -1), ...simplify(pts.slice(idx), tol)];
}

(async () => {
  let line = [];
  let km = 0;
  for (let i = 0; i < STOPS.length - 1; i++) {
    const a = STOPS[i], b = STOPS[i + 1];
    const url = `https://router.project-osrm.org/route/v1/driving/${a[2]},${a[1]};${b[2]},${b[1]}?overview=full&geometries=geojson&alternatives=2`;
    const r = await (await fetch(url, { headers: { "User-Agent": "smart-orkhon-dev/1.0" } })).json();
    const rt = r.routes[PICK[i] ?? 0];
    km += rt.distance / 1000;
    const pts = rt.geometry.coordinates.map(([lng, lat]) => [lat, lng]);
    console.error(`leg ${i} ${a[0]} -> ${b[0]}: ${(rt.distance / 1000).toFixed(2)} km (alt ${PICK[i] ?? 0} of ${r.routes.length})`);
    line = line.length ? [...line, ...pts.slice(1)] : pts;
    await new Promise((res) => setTimeout(res, 1100));
  }
  // Stops sit beside the road, so OSRM drives into a side street and back out. Cut those out-and-back spurs:
  // when the line returns within 12 m of an earlier point after a short detour (< 900 m), drop the detour.
  const len = (a, i, j) => { let d = 0; for (let k = i; k < j; k++) d += m(a[k], a[k + 1]); return d; };
  let cut = 0, changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < line.length && !changed; i++) {
      for (let j = i + 2; j < line.length; j++) {
        const d = len(line, i, j);
        if (d > 900) break;
        if (m(line[i], line[j]) < 12 && d > 30) { line.splice(i + 1, j - i); cut++; changed = true; break; }
      }
    }
  }
  console.error(`spurs cut: ${cut}, length now ${(len(line, 0, line.length - 1) / 1000).toFixed(1)} km`);
  const s = simplify(line, 6).map(([la, ln]) => [+la.toFixed(5), +ln.toFixed(5)]);
  console.error(`total ${km.toFixed(1)} km, ${line.length} -> ${s.length} points; first/last gap ${m(s[0], s[s.length - 1]).toFixed(0)} m`);
  console.log(JSON.stringify(s));
})();
